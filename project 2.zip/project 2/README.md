# CS-3300-P2
Interactive Data Vis

Hotel vs Airbnb Data for 20 major US cities in 2015:
https://qz.com/779121/airbnb-vs-hotel-cost-comparison-you-can-rent-an-entire-home-on-airbnb-for-the-price-of-a-hotel-room/

Latitude and Longitude of major cities: http://www.artscipub.com/info/latlonofmajorcities.asp

Average airfare from major cities: https://www.transtats.bts.gov/AverageFare/

Average cost of restaurant meal: https://www.numbeo.com/cost-of-living/country_result.jsp?country=United+States



